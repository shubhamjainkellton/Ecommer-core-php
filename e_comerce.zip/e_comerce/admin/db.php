<?php
$connection = mysqli_connect('localhost', 'root','', 'ecommerce');

/*if($connection)
{
    echo "we are connected" ;
}*/
?>