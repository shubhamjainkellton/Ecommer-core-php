<?php

$login = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){

  include "db.php";

  $email = $_POST["email"];
  $password = $_POST["password"];
  
  $sql = "SELECT * FROM signup WHERE email='{$email}'";
  $result = mysqli_query($connection,$sql);
  $num = mysqli_num_rows($result);
  if($num == 1){
    while($row=mysqli_fetch_assoc($result)){
      if(password_verify($password, $row['password'])){
        $login = true;
        //Session 
        session_start();
        $_SESSION["loggedin"] = true;
        $_SESSION["email"] = $email; 
        $_SESSION["sno"] = $sno;
        
        //Webpage Redirect
        header("location: index.php");
      }
    }
    
  }else{
    echo "Please Check the Email and Password";
  }



}


?>
<div class="content-wrapper oh">

<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<form method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1>login </h1>
    
    <hr>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" id="email" name="email" required>
    

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password"  id="password" name="password" required>

    
    <div class="clearfix">
      <button type="submit" class="" name="login">login</button>
    </div>
  </div>
</form>


